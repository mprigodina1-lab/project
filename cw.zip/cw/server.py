import dataclasses
import http.server
import json
import pathlib
from typing import Optional
import urllib.parse
import psycopg2

DB_HOST = "192.168.*.*"
DB_PORT = 5432
DB_USER = "airflow"
DB_PASSWORD = "airflow"
DB_NAME = "meteo"
ROOT_PATH = "./src"

@dataclasses.dataclass
class WeatherData:
    icon_file: str
    id: int
    date: str
    weather_id: int
    weather_main: str
    weather_description: str
    weather_icon: str
    current_temp: float
    current_feels_like: float
    current_pressure: int
    current_humidity: float
    current_visibility: int
    current_wind_speed: float
    current_wind_deg: int
    current_wind_desc: str
    current_clouds: Optional[float]
    current_rain_1h: Optional[float]
    current_snow_1h: Optional[float]
    current_sunrise: str
    current_sunset: str
    current_uvi: Optional[float]
    current_dew_point: Optional[float]
    current_wind_gust: float


def get_weather_data() -> WeatherData:
    with psycopg2.connect(
        user=DB_USER,
        password=DB_PASSWORD,
        dbname=DB_NAME,
        host=DB_HOST,
        port=DB_PORT,
    ) as conn:
        with conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT './assets/'
                    || REPLACE(b.weather_description, ' ','-') || '_'
                    || CASE WHEN date_part('MONTH', b.date) IN (1,2,3,4,10,11,12) THEN 'зима_'
                       ELSE 'лето_' END
                    || CASE WHEN date_part('HOUR', b.date) IN (0,1,2,3,22,23,24) THEN 'ночь'
                            WHEN date_part('HOUR', b.date) IN (4,5,6,7,8,9) THEN 'утро'
                            WHEN date_part('HOUR', b.date) IN (10,11,12,13,14,15) THEN 'день'
                       ELSE 'вечер' END
                    || '.png' AS icon_file,* FROM "meteo"."get_current_weather"() b
                """
            )
            result = cursor.fetchone()

            return WeatherData(*result)


class RequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path not in {"/", "/weather"} and not self.path.startswith("/assets"):
            self.send_error(http.HTTPStatus.NOT_FOUND)
            return

        if self.path == "/":
            self.send_response(http.HTTPStatus.OK, message="Ok")
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            with open("./src/index.html", encoding="utf-8") as file:
                data = file.read().encode("utf-8")
                self.wfile.write(data)

            return

        if self.path.startswith("/assets"):
            self.send_response(http.HTTPStatus.OK, message="Ok")
            self.send_header("Content-type", "image/png")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            root_path = pathlib.Path(ROOT_PATH).resolve()
            file_path = pathlib.Path(
                urllib.parse.unquote(self.path.strip("/"))
            )
            full_file_path = (root_path / file_path).resolve()
            if full_file_path.is_file() and full_file_path.is_relative_to(root_path):
                with full_file_path.open("rb") as file:
                    self.wfile.write(file.read())
                return

            else:
                self.send_error(http.HTTPStatus.NOT_FOUND)
                return

        self.send_response(http.HTTPStatus.OK, message="Ok")
        self.send_header("Content-type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        data = get_weather_data()
        self.wfile.write(
            json.dumps(
                dataclasses.asdict(data),
                ensure_ascii=False,
                default=str,
            ).encode("utf-8")
        )

    @staticmethod
    def fetch_weather_data():
        pass

class WeatherServer:
    def __init__(self, host, port):
        self.host = host
        self.port = port

        self.server = http.server.ThreadingHTTPServer(
            (self.host, self.port),
            RequestHandler
        )

    def run(self) -> None:
        print(f"Запускаем сервер на http://{self.host}:{self.port}")
        return self.server.serve_forever()


WeatherServer("localhost", 8085).run()
